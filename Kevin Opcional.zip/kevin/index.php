<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CRUD Biblioteca</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>

<body>
    <div class="container mt-5">
        <h2>Autores</h2>
        <table class="table table-bordered">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Nombre</th>
                    <th>Acciones</th>
                </tr>
            </thead>
            <tbody id="authorsTableBody"></tbody>
        </table>

        <h2>Agregar Nuevo Autor</h2>
        <form id="addAuthorForm">
            <div class="form-group">
                <label for="authorName">Nombre del Autor</label>
                <input type="text" class="form-control" id="authorName" name="authorName" required>
            </div>
            <button type="submit" class="btn btn-primary">Agregar Autor</button>
        </form>
    </div>

    <div class="modal fade" id="bookModal" tabindex="-1" role="dialog" aria-labelledby="bookModalLabel"
        aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="bookModalLabel">Agregar Libro</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <form id="addBookForm">
                        <div class="form-group">
                            <label for="bookTitle">Título del Libro</label>
                            <input type="text" class="form-control" id="bookTitle" name="bookTitle" required>
                        </div>
                        <div class="form-group">
                            <label for="bookAuthorId">ID del Autor</label>
                            <input type="text" class="form-control" id="bookAuthorId" name="bookAuthorId" required>
                        </div>
                        <button type="submit" class="btn btn-primary">Agregar Libro</button>
                    </form>
                </div>
            </div>
        </div>
    </div>


    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.10.2/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>

    <script>
        $(document).ready(function () {
            loadAuthors();

            $("#addAuthorForm").submit(function (event) {
                event.preventDefault();

                var authorName = $("#authorName").val();
                addAuthor(authorName);
            });

            $("#showBooksBtn").click(function () {
                loadBooks();
            });

            $("#addBookForm").submit(function (event) {
                event.preventDefault();

                var title = $("#bookTitle").val();
                var authorId = $("#bookAuthorId").val();
                addBook(title, authorId);
            });
        });

        function loadAuthors() {
            $.ajax({
                type: "POST",
                url: "library_client.php",
                data: {
                    operation: "getAuthors"
                },
                success: function (response) {
                    try {
                        var authors = JSON.parse(response);
                        var authorsTableBody = $("#authorsTableBody");
                        authorsTableBody.empty();

                        for (var i = 0; i < authors.length; i++) {
                            var author = authors[i];
                            var row = "<tr>" +
                                "<td>" + author.id + "</td>" +
                                "<td>" + author.nombre + "</td>" +
                                "<td>" +
                                "<button class='btn btn-warning' onclick='editAuthor(" + author.id + ")'>Editar</button>" +
                                "<button class='btn btn-danger' onclick='deleteAuthor(" + author.id + ")'>Eliminar</button>" +
                                "<button class='btn btn-primary' onclick='showBooks(" + author.id + ")'>Mostrar Libros</button>" +
                                "</td>" +
                                "</tr>";
                            authorsTableBody.append(row);
                        }
                    } catch (e) {
                        console.error("Error al analizar la respuesta JSON: " + e);
                    }
                }
            });
        }

        function addAuthor(authorName) {
            $.ajax({
                type: "POST",
                url: "library_client.php",
                data: {
                    operation: "addAuthor",
                    authorName: authorName
                },
                success: function (response) {
                    alert(response);
                    loadAuthors();
                }
            });
        }

        function loadBooks() {
            $.ajax({
                type: "POST",
                url: "library_client.php",
                data: {
                    operation: "getBooks"
                },
                success: function (response) {
                    try {
                        var books = JSON.parse(response);
                    } catch (e) {
                        console.error("Error al analizar la respuesta JSON: " + e);
                    }
                }
            });
        }

        function addBook(title, authorId) {
            $.ajax({
                type: "POST",
                url: "library_client.php",
                data: {
                    operation: "addBook",
                    title: title,
                    authorId: authorId
                },
                success: function (response) {
                    alert(response);
                    loadBooks();
                    $("#bookModal").modal("hide");
                }
            });
        }

        function editAuthor(authorId) {
            var newAuthorName = prompt("Ingrese el nuevo nombre del autor:");

            if (newAuthorName !== null) {
                $.ajax({
                    type: "POST",
                    url: "library_client.php",
                    data: {
                        operation: "editAuthor",
                        authorId: authorId,
                        authorName: newAuthorName
                    },
                    success: function (response) {
                        alert(response);
                        loadAuthors();
                    }
                });
            }
        }

        function deleteAuthor(authorId) {
            var confirmDelete = confirm("¿Estás seguro de que deseas eliminar este autor?");

            if (confirmDelete) {
                $.ajax({
                    type: "POST",
                    url: "library_client.php",
                    data: {
                        operation: "deleteAuthor",
                        authorId: authorId
                    },
                    success: function (response) {
                        alert(response);
                        loadAuthors();
                    }
                });
            }
        }

        function showBooks(authorId) {
            $.ajax({
                type: "POST",
                url: "library_client.php",
                data: {
                    operation: "getBooks",
                    authorId: authorId
                },
                success: function (response) {
                    try {
                        var books = JSON.parse(response);
                        var booksList = "<ul>";

                        for (var i = 0; i < books.length; i++) {
                            var book = books[i];
                            booksList += "<li>" + book.titulo + "</li>";
                        }

                        booksList += "</ul>";
                        alert("Libros del Autor:\n" + booksList);
                    } catch (e) {
                        console.error("Error al analizar la respuesta JSON: " + e);
                    }
                }
            });
        }
    function loadBooks() {
        $.ajax({
            type: "POST",
            url: "library_client.php",
            data: {
                operation: "getBooks"
            },
            success: function (response) {
                var books = JSON.parse(response);
                var booksList = "<h2>Libros</h2><ul>";

                for (var i = 0; i < books.length; i++) {
                    var book = books[i];
                    booksList += "<li>" + book.titulo + " (Autor ID: " + book.autor_id + ")</li>";
                }

                booksList += "</ul>";
                $("#booksContainer").html(booksList);
            }
        });
    }
    </script>

</body>

</html>
