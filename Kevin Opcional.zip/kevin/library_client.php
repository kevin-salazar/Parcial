<?php
require_once('lib/nusoap.php');
require_once('LibraryService.php');
$client = new nusoap_client('http://localhost/kevin/library_service.php?wsdl', 'wsdl');

$err = $client->getError();
if ($err) {
    echo 'Error al crear el cliente: ' . $err;
    exit();
}

function addAuthor($authorName) {
    global $client;
    $response = $client->call('LibraryService.addAuthor', array('authorName' => $authorName));

    if ($client->fault) {
        echo 'Error en la llamada: ' . $response;
    } else {
        echo 'Resultado de agregar autor: ' . $response;
    }
}

function getAuthors() {
    global $client;
    $response = $client->call('LibraryService.getAuthors');
    
    if ($client->fault) {
        echo 'Error en la llamada: ' . $response;
    } else {
        echo 'Autores obtenidos: ' . $response;
    }
}

function editAuthor($authorId, $authorName) {
    global $client;
    $response = $client->call('LibraryService.editAuthor', array('authorId' => $authorId, 'authorName' => $authorName));

    if ($client->fault) {
        echo 'Error en la llamada: ' . $response;
    } else {
        echo 'Resultado de editar autor: ' . $response;
    }
}

function deleteAuthor($authorId) {
    global $client;
    $response = $client->call('LibraryService.deleteAuthor', array('authorId' => $authorId));

    if ($client->fault) {
        echo 'Error en la llamada: ' . $response;
    } else {
        echo 'Resultado de eliminar autor: ' . $response;
    }
}

function addBook($title, $authorId) {
    global $client;
    $response = $client->call('LibraryService.addBook', array('title' => $title, 'authorId' => $authorId));

    if ($client->fault) {
        echo 'Error en la llamada: ' . $response;
    } else {
        echo 'Resultado de agregar libro: ' . $response;
    }
}

function getBooks() {
    global $client;
    $response = $client->call('LibraryService.getBooks');

    if ($client->fault) {
        echo 'Error en la llamada: ' . $response;
    } else {
        echo 'Libros obtenidos: ' . $response;
    }
}

function editBook($bookId, $title, $authorId) {
    global $client;
    $response = $client->call('LibraryService.editBook', array('bookId' => $bookId, 'title' => $title, 'authorId' => $authorId));

    if ($client->fault) {
        echo 'Error en la llamada: ' . $response;
    } else {
        echo 'Resultado de editar libro: ' . $response;
    }
}

function deleteBook($bookId) {
    global $client;
    $response = $client->call('LibraryService.deleteBook', array('bookId' => $bookId));

    if ($client->fault) {
        echo 'Error en la llamada: ' . $response;
    } else {
        echo 'Resultado de eliminar libro: ' . $response;
    }
}
?>