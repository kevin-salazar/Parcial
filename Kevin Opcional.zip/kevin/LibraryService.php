
<?php
require_once('lib/nusoap.php');

class LibraryService
{
    private $mysqli;

    public function __construct()
    {
        $this->mysqli = new mysqli("localhost", "root", "", "biblioteca");

        if ($this->mysqli->connect_error) {
            die('Error de conexión (' . $this->mysqli->connect_errno . ') ' . $this->mysqli->connect_error);
        }
    }

    public function getAuthors()
    {
        $result = $this->mysqli->query("SELECT * FROM autor");
        $authors = array();

        while ($row = $result->fetch_assoc()) {
            $authors[] = $row;
        }

        return json_encode($authors);
    }

    public function addAuthor($authorName)
    {
        $stmt = $this->mysqli->prepare("INSERT INTO autor (nombre) VALUES (?)");
        $stmt->bind_param("s", $authorName);
        $stmt->execute();
        $stmt->close();

        return "Autor agregado correctamente.";
    }

    public function editAuthor($authorId, $authorName)
    {
        $stmt = $this->mysqli->prepare("UPDATE autor SET nombre = ? WHERE id = ?");
        $stmt->bind_param("si", $authorName, $authorId);
        $stmt->execute();
        $stmt->close();

        return "Autor actualizado correctamente.";
    }

    public function deleteAuthor($authorId)
    {
        $stmt = $this->mysqli->prepare("DELETE FROM autor WHERE id = ?");
        $stmt->bind_param("i", $authorId);
        $stmt->execute();
        $stmt->close();
   
        return "Autor eliminado correctamente.";
    }
   
    public function getBooks()
    {
        $result = $this->mysqli->query("SELECT * FROM libro");
        $books = array();
   
        while ($row = $result->fetch_assoc()) {
            $books[] = $row;
        }
   
        return json_encode($books);
    }
   
    public function addBook($title, $authorId)
    {
        $stmt = $this->mysqli->prepare("INSERT INTO libro (titulo, autor_id) VALUES (?, ?)");
        $stmt->bind_param("si", $title, $authorId);
        $stmt->execute();
        $stmt->close();
   
        return "Libro agregado correctamente.";
    }
   
    public function editBook($bookId, $title, $authorId)
    {
        $stmt = $this->mysqli->prepare("UPDATE libro SET titulo = ?, autor_id = ? WHERE id = ?");
        $stmt->bind_param("sii", $title, $authorId, $bookId);
        $stmt->execute();
        $stmt->close();
   
        return "Libro actualizado correctamente.";
    }
   
    public function deleteBook($bookId)
    {
        $stmt = $this->mysqli->prepare("DELETE FROM libro WHERE id = ?");
        $stmt->bind_param("i", $bookId);
        $stmt->execute();
        $stmt->close();
   
        return "Libro eliminado correctamente.";
    }
}

$server = new soap_server();
$server->configureWSDL('LibraryService', 'http://localhost/kevin');
$server->register('LibraryService.getAuthors');
$server->register('LibraryService.addAuthor');
$server->register('LibraryService.editAuthor');
$server->register('LibraryService.deleteAuthor');
$server->register('LibraryService.getBooks');
$server->register('LibraryService.addBook');
$server->register('LibraryService.editBook');
$server->register('LibraryService.deleteBook');

$HTTP_RAW_POST_DATA = isset($HTTP_RAW_POST_DATA) ? $HTTP_RAW_POST_DATA : '';
$server->service($HTTP_RAW_POST_DATA);
?>